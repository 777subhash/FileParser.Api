﻿using System.Net.Http.Headers;

using (var client = new HttpClient())
{
    client.BaseAddress = new Uri("http://localhost:5101");
    var authString = $"admin:admin";
    var basicAuthString = Convert.ToBase64String(System.Text.ASCIIEncoding.ASCII.GetBytes(authString));

    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", basicAuthString);

    var photoFileName = @"C:\boot-flutter-2.png";

    var photo1Content = new ByteArrayContent(await File.ReadAllBytesAsync(photoFileName));
    photo1Content.Headers.ContentType = MediaTypeHeaderValue.Parse("image/jpeg");
    photo1Content.Headers.ContentType.Parameters.Add(new NameValueHeaderValue("parameter1", "value1"));

    var photo2Content = new ByteArrayContent(await File.ReadAllBytesAsync(photoFileName));
    photo2Content.Headers.ContentType = MediaTypeHeaderValue.Parse("image/jpeg");
    photo2Content.Headers.ContentType.Parameters.Add(new NameValueHeaderValue("parameter1", "value1"));

    var content = new MultipartFormDataContent()
                {
                    {  photo1Content, "Photo_1", "Photo_1" },
                    {  photo2Content, "Photo_2", "Photo_2" }
                };


    var photo1Response = await client.PostAsync($"api/parser", content);
    photo1Response.EnsureSuccessStatusCode();
    var resultFile = await photo1Response.Content.ReadAsStringAsync();

    Console.WriteLine("Done.");
    Console.ReadLine();
}
