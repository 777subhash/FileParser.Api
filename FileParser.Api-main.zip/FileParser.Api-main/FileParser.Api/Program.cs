using FileParser.Api;
using FileParser.Core;
using Microsoft.AspNetCore.Authentication;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var directory = Path.Combine(Path.GetTempPath(), "pdf-parser");
if(!Directory.Exists(directory))
    Directory.CreateDirectory(directory);

builder.Services.AddSingleton(new FileRepository(directory));
builder.Services.AddSingleton(new PdfFileParser(directory));
builder.Services.AddSingleton(new AuthenticationRepository());

builder.Services.AddAuthentication("Basic").AddScheme<AuthenticationSchemeOptions, BasicAuthenticationHandler>("Basic", o => { });

var app = builder.Build();


// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseAuthorization();

app.MapControllers();

app.Run();
