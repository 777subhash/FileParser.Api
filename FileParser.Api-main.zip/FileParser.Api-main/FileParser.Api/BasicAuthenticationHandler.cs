﻿using FileParser.Core;
using Microsoft.AspNetCore.Authentication;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Linq;
using System.Net.Http.Headers;
using System.Security.Claims;
using System.Text;
using System.Text.Encodings.Web;
using System.Threading.Tasks;

namespace FileParser.Api
{
    public class BasicAuthenticationHandler : AuthenticationHandler<AuthenticationSchemeOptions>
    {
        public BasicAuthenticationHandler(
            IOptionsMonitor<AuthenticationSchemeOptions> options,
            ILoggerFactory logger, UrlEncoder encoder, ISystemClock clock
            ) : base(options, logger, encoder, clock)
        {
        }

        protected override Task<AuthenticateResult> HandleAuthenticateAsync()
        {
            Response.Headers.Add("WWW-Authenticate", "Basic");

            if (!Request.Headers.ContainsKey("Authorization"))
                return Task.FromResult(AuthenticateResult.NoResult());

            var authHeader = AuthenticationHeaderValue.Parse(Request.Headers["Authorization"]);
            if (authHeader?.Scheme != "Basic")
                return Task.FromResult(AuthenticateResult.NoResult());

            var authParameters = Encoding.UTF8.GetString(Convert.FromBase64String(authHeader.Parameter)).Split(':');
            if (authParameters?.Length != 2)
                return Task.FromResult(AuthenticateResult.Fail("Authorization code not formatted properly."));

            var username = authParameters[0];
            var password = authParameters[1];

            try
            {
                var userRepository = this.Context.RequestServices.GetRequiredService<AuthenticationRepository>();
                if(userRepository.Authenticate(username, password))
                {
                    var claimsPrincipal = new ClaimsPrincipal(new ClaimsIdentity("Basic"));
                    return Task.FromResult(AuthenticateResult.Success(new AuthenticationTicket(claimsPrincipal, Scheme.Name)));
                } 
                else
                {
                    return Task.FromResult(AuthenticateResult.Fail("Wrong username or password"));
                }
            }
            catch (Exception ex)
            {
                return Task.FromResult(AuthenticateResult.Fail(ex.Message));
            }
        }
    }
}
