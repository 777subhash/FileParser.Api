﻿using FileParser.Core;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http.Headers;
using System.Security.Claims;
using System.Threading.Tasks;

namespace FileParser.Api
{
    public static class Extensions
    {
        public static async Task<string> SaveFile(this FileRepository repository, IFormFile file)
        {
            Console.WriteLine($"Photo recieved with content type: '{file.ContentType}'");

            if (!MediaTypeHeaderValue.TryParse(file.ContentType, out var contentType))
                throw new ArgumentException("Cannot parse content type.");

            Console.WriteLine($"Parsed content type: '{contentType.MediaType}'");

            foreach (var par in contentType.Parameters)
                Console.WriteLine($"Parameter '{par.Name}': '{par.Value}'");

            using (var stream = file.OpenReadStream())
            {
                return await repository.SaveFile(stream, $"{Guid.NewGuid().ToString()}.pdf");
            }
        }

        public static async Task<string[]> SaveFiles(this FileRepository repository, IFormFileCollection files)
        {
            return await Task.WhenAll(files.Select(f => repository.SaveFile(f)));
        }

        public static async Task<FileStreamResult> AsFileResult(this string fileName, string contentType, bool deleteFile)
        {
            try
            {
                using (var fileStream = File.OpenRead(fileName))
                {
                    var memoryStream = new MemoryStream();
                    await fileStream.CopyToAsync(memoryStream);

                    memoryStream.Position = 0;
                    return new FileStreamResult(memoryStream, contentType);
                }
            }
            finally
            {
                if(deleteFile)
                    File.Delete(fileName);
            }
       
        }
    }
}
