using FileParser.Core;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using DLLParser;

namespace FileParser.Api.Controllers
{
    [ApiController]
    [Authorize(AuthenticationSchemes = "Basic")]
    [Route("api/[controller]")]
    public class ParserController : ControllerBase
    {
        private readonly FileRepository fileRepository;
        private readonly PdfFileParser fileParser;

        public ParserController(FileRepository fileRepository, PdfFileParser fileParser)
        {
            this.fileRepository = fileRepository ?? throw new ArgumentNullException(nameof(fileRepository));
            this.fileParser = fileParser ?? throw new ArgumentNullException(nameof(fileParser));
        }

        [HttpGet("status")]
        public string Status()
        {
            return "o";
        }

        [HttpPost]
        public async Task<IActionResult> ParseFiles()
        {
            try
            {
                string dir = "";
                string resultExcelFile;
                dir = fileRepository.getdirectory();

                System.IO.DirectoryInfo di = new DirectoryInfo(dir);
                foreach (FileInfo file in di.GetFiles())
                {
                    file.Delete();
                }

                var formCollection = await Request.ReadFormAsync();
                var fileNames = await fileRepository.SaveFiles(formCollection.Files);
                var resultFileName = fileParser.ParseFiles(fileNames);
                string[] PdfFileNames = new string[formCollection.Files.Count];
                string[] NewPdfFileNames = new string[formCollection.Files.Count];
                

                for ( int i = 0; i < PdfFileNames.Length; i++)
                {
                    PdfFileNames[i] = formCollection.Files[i].FileName;
 //                   dir = Path.GetDirectoryName(fileNames[i]);
                    NewPdfFileNames[i] = Path.Combine(dir, PdfFileNames[i]);
                    System.IO.File.Move(fileNames[i], NewPdfFileNames[i]);
                }
                ClassProcessPDF processPDF = new ClassProcessPDF(PdfFileNames, false, dir);
                resultExcelFile = processPDF.convert();


                return new PhysicalFileResult(resultExcelFile, "application/vnd.ms-excel");



                // deletes temp files
                // todo remove skip(1)
                fileRepository.DeleteFiles(fileNames.Skip(1).ToArray());

                // content-type: application/vnd.ms-excel
                // content-type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet

                //return new PhysicalFileResult(resultFileName, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
                //return new PhysicalFileResult(fileNames[0], "image/png");

                // deletes temp file after returning file
                return await fileNames[0].AsFileResult("image/png", true); 
            }
            catch (Exception ex)
            {
               Console.WriteLine(ex.Message);
               throw;
            }
            //string[] temp = Directory.GetFiles(environmentParams.Tempfolder(), "*.pdf");
            //string[] PdfFileNames = new string[temp.Length];
            //for (int k = 0; k < temp.Length; k++)
            //{
            //    PdfFileNames[k] = Path.GetFileName(temp[k]);
            //}
            //ClassProcessPDF processPDF = new ClassProcessPDF(PdfFileNames, environmentParams.DebugMode(), environmentParams.Tempfolder());
            //resultExcelFile = processPDF.convert();

        }
    }
}