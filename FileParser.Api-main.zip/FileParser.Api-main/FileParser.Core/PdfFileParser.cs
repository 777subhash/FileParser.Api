﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileParser.Core
{
    public class PdfFileParser
    {
        private readonly string directory;
        public PdfFileParser(string directory)
        {
            this.directory = directory ?? throw new ArgumentNullException(nameof(directory));
        }


        public string ParseFiles(string[] files)
        {
            return "Parsed File Path";
        }
    }
}
