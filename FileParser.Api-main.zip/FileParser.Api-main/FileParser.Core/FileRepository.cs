﻿namespace FileParser.Core
{
    public class FileRepository
    {
        private readonly string directory;
        public FileRepository(string directory)
        {
            this.directory = directory ?? throw new ArgumentNullException(nameof(directory));
        }

        public async Task<string> SaveFile(Stream stream, string fileName)
        {
            var path = Path.Combine(directory, fileName);
            using (Stream fileStream = new FileStream(path, FileMode.Create))
            {
                await stream.CopyToAsync(fileStream);
            }

            return path;
        }

        public void DeleteFiles(string[] fileNames)
        {
            foreach(var file in fileNames)
                DeleteFile(file);
        }

        public void DeleteFile(string fileName)
        {
            if(File.Exists(fileName))
                File.Delete(fileName);
            else
            {
                var path = Path.Combine(directory, fileName);
                if (File.Exists(path))
                    File.Delete(path);
            }
        }
        public string getdirectory()
        {
            return directory;
        }
    }
}