﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileParser.Core
{
    public class AuthenticationRepository
    {
        public bool Authenticate(string userName, string password)
        {
            return userName == "admin" && password == "admin";
        }
    }
}
